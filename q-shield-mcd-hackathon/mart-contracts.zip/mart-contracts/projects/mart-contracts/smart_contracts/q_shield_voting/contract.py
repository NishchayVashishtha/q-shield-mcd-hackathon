import algopy
from algopy import ARC4Contract, String, Global, Txn, arc4

class QShieldVoting(ARC4Contract):
    def __init__(self) -> None:
        self.admin            = Global.creator_address
        self.is_voting_active = algopy.UInt64(0)
        self.votes_alpha      = algopy.UInt64(0)
        self.votes_beta       = algopy.UInt64(0)

    @arc4.abimethod
    def start_election(self) -> None:
        assert Txn.sender == self.admin, "Unauthorized: Only Admin can start the election."
        self.is_voting_active = algopy.UInt64(1)

    @arc4.abimethod
    def stop_election(self) -> None:
        assert Txn.sender == self.admin, "Unauthorized: Only Admin can stop the election."
        self.is_voting_active = algopy.UInt64(0)

    @arc4.abimethod
    def cast_vote(self, fhe_encrypted_payload: String, candidate_id: algopy.UInt64) -> None:
        """candidate_id: 1=Alpha, 2=Beta"""
        assert self.is_voting_active == algopy.UInt64(1), "Election is currently closed."
        if candidate_id == algopy.UInt64(1):  # type: ignore[misc]
            self.votes_alpha = self.votes_alpha + algopy.UInt64(1)  # type: ignore[misc]
        else:
            self.votes_beta = self.votes_beta + algopy.UInt64(1)  # type: ignore[misc]

import os
from pathlib import Path
from algokit_utils import AlgorandClient, AlgoAmount, SigningAccount
from algosdk import mnemonic, account as algo_account

def deploy(*args, **kwargs) -> None:
    # 1. Testnet se connect karo
    algorand = AlgorandClient.testnet()

    # 2. Deployer account — mnemonic env variable se lo
    deployer_mnemonic = os.environ.get("DEPLOYER_MNEMONIC")
    if not deployer_mnemonic:
        raise Exception(
            "❌ DEPLOYER_MNEMONIC environment variable set nahi hai!\n"
            "   Pehle .env file mein apna testnet mnemonic daalo."
        )

    private_key = mnemonic.to_private_key(deployer_mnemonic)
    deployer_address = algo_account.address_from_private_key(private_key)
    deployer = SigningAccount(private_key=private_key, address=deployer_address)

    print(f"🔑 Deployer Address: {deployer.address}")
    print(f"🌐 Network: Algorand Testnet")

    # 3. ARC56 JSON uthao
    artifact_dir = Path(__file__).parent.parent / "artifacts" / "q_shield_voting"
    arc56_file = next(artifact_dir.glob("*.arc56.json"))

    # 4. Factory banao aur deploy karo
    factory = algorand.client.get_app_factory(
        app_spec=arc56_file.read_text(),
        default_sender=deployer.address,
        default_signer=deployer.signer
    )

    app_client, result = factory.deploy(
        on_schema_break="append",
        on_update="append"
    )

    print("\n" + "🔥" * 25)
    print(f"✅ TESTNET VAULT APP ID: {app_client.app_id}")
    print(f"🔗 Explorer: https://testnet.explorer.perawallet.app/application/{app_client.app_id}/")
    print("🔥" * 25 + "\n")
